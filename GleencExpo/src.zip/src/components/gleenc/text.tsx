import { Text, type TextProps } from 'react-native';
import { Colors } from '@/constants/theme';

type Props = TextProps & { weight?: 'light' | 'medium' | 'bold'; tone?: 'ink' | 'muted' | 'red' | 'white' };
export function GText({ weight = 'medium', tone = 'ink', style, ...props }: Props) {
  const color = tone === 'muted' ? Colors.light.textMuted : tone === 'red' ? Colors.light.red : tone === 'white' ? '#FFFFFF' : Colors.light.text;
  const fontFamily = weight === 'bold' ? 'ReoSans-Bold' : weight === 'light' ? 'ReoSans-Light' : 'ReoSans-Medium';
  return <Text {...props} style={[{ fontFamily, color, includeFontPadding: false }, style]} />;
}
