import { useState } from 'react';
import { Image, Modal, Pressable, ScrollView, Share, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { GText } from '@/components/gleenc/text';
import { Colors } from '@/constants/theme';
import type { FeedItem } from './data';
import { formatPrice } from './data';
import { useFeedState } from './feed-state';
import { Comments } from './comments';

export function ProductPost({ item, height }: { item: FeedItem; height: number }) {
  const { liked, saved, followed, toggleLike, toggleSave, toggleFollow, addToCart } = useFeedState();
  const [qty, setQty] = useState(1);
  const [photo, setPhoto] = useState(0);
  const [details, setDetails] = useState(false);
  const [commentsOpen, setCommentsOpen] = useState(false);
  const images = item.images?.length ? item.images : [item.image];
  return <Animated.View entering={FadeInDown.duration(250)} style={[styles.card, { height: Math.max(height - 12, 540) }]}>
    <View style={styles.seller}>
      <View style={styles.avatar}><GText weight="bold" tone="white">{item.store.charAt(0)}</GText></View>
      <View style={{ flex: 1 }}><GText weight="bold" style={{ fontSize: 14 }}>{item.store}</GText><GText tone="muted" style={{ fontSize: 11 }}>{item.handle}</GText></View>
      <Pressable style={styles.follow} onPress={() => toggleFollow(item.store)} accessibilityLabel={`Follow ${item.store}`}><GText tone="white" weight="bold" style={{ fontSize: 12 }}>{followed.includes(item.store) ? 'Following' : 'Follow'}</GText></Pressable>
    </View>
    <View style={styles.hero}>
      <Image source={{ uri: images[photo] }} style={StyleSheet.absoluteFillObject} resizeMode="cover" />
      {images.length > 1 && <><Pressable style={[styles.arrow, { left: 12 }]} onPress={() => setPhoto((photo + images.length - 1) % images.length)} accessibilityLabel="Previous image"><Ionicons name="chevron-back" size={18} color="#111626" /></Pressable><Pressable style={[styles.arrow, { right: 12 }]} onPress={() => setPhoto((photo + 1) % images.length)} accessibilityLabel="Next image"><Ionicons name="chevron-forward" size={18} color="#111626" /></Pressable></>}
      <View style={styles.status}><GText weight="bold" style={{ fontSize: 11 }}>{item.stock ? 'Available' : 'Sold out'}</GText></View>
      <View style={styles.dots}>{images.map((_, i) => <View key={i} style={[styles.dot, i === photo && styles.dotActive]} />)}</View>
      <View style={styles.views}><Ionicons name="eye-outline" size={12} color="#FFF" /><GText tone="white" style={{ fontSize: 11 }}> {item.views} views</GText></View>
    </View>
    <View style={styles.body}>
      <View style={styles.actions}><Pressable onPress={() => toggleLike(item.id)} style={styles.action} accessibilityLabel="Like product"><Ionicons name={liked.includes(item.id) ? 'heart' : 'heart-outline'} color={liked.includes(item.id) ? Colors.light.red : Colors.light.text} size={24} /><GText style={{ fontSize: 12 }}>{item.likes + (liked.includes(item.id) ? 1 : 0)}</GText></Pressable>
        <Pressable onPress={() => setCommentsOpen(true)} style={styles.action} accessibilityLabel="Open comments"><Ionicons name="chatbubble-outline" size={22} color={Colors.light.text} /><GText style={{ fontSize: 12 }}>{item.comments}</GText></Pressable>
        <Pressable onPress={() => Share.share({ message: `${item.name} · ${formatPrice(item.priceKobo)} on Gleenc` })} style={styles.action} accessibilityLabel="Share"><Ionicons name="paper-plane-outline" size={23} color={Colors.light.text} /></Pressable>
        <Pressable onPress={() => toggleSave(item.id)} style={{ marginLeft: 'auto' }} accessibilityLabel="Save product"><Ionicons name={saved.includes(item.id) ? 'bookmark' : 'bookmark-outline'} size={24} color={saved.includes(item.id) ? Colors.light.red : Colors.light.text} /></Pressable></View>
      <View style={styles.pill}><GText tone="red" weight="bold" style={{ fontSize: 10 }}>MARKETPLACE</GText></View>
      <GText weight="bold" numberOfLines={1} style={{ fontSize: 17, marginTop: 5 }}>{item.name}</GText>
      <GText tone="muted" style={{ fontSize: 12, marginTop: 4 }}>{item.category} · {item.stock} in stock</GText>
      <View style={styles.priceRow}><GText weight="bold" style={{ fontSize: 21 }}>{formatPrice(item.priceKobo)}</GText><View style={styles.stepper}><Pressable onPress={() => setQty(q => Math.max(1, q - 1))} accessibilityLabel="Decrease quantity"><Ionicons name="remove" size={18} color={Colors.light.text} /></Pressable><GText style={{ paddingHorizontal: 12 }}>{qty}</GText><Pressable onPress={() => setQty(q => Math.min(Math.max(item.stock, 1), q + 1))} accessibilityLabel="Increase quantity"><Ionicons name="add" size={18} color={Colors.light.text} /></Pressable></View></View>
      <View style={styles.bottom}><Pressable onPress={() => addToCart(item, qty)} style={styles.cart} accessibilityLabel="Add to cart"><Ionicons name="cart-outline" size={22} color="#FFF" /></Pressable><Pressable onPress={() => setDetails(true)} style={styles.details}><GText tone="white" weight="bold" style={{ fontSize: 13 }}>View Details</GText></Pressable></View>
    </View>
    <Comments open={commentsOpen} close={() => setCommentsOpen(false)} title={item.name} />
    <Modal visible={details} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setDetails(false)}><ScrollView style={{ backgroundColor: '#FFF' }}><View style={styles.modalHeader}><GText weight="bold" style={{ fontSize: 20 }}>Product details</GText><Pressable onPress={() => setDetails(false)}><Ionicons name="close" size={27} color={Colors.light.text} /></Pressable></View><Image source={{ uri: item.image }} style={{ width: '100%', height: 350 }} /><View style={{ padding: 22, gap: 11 }}><GText weight="bold" style={{ fontSize: 23 }}>{item.name}</GText><GText weight="bold" tone="red" style={{ fontSize: 21 }}>{formatPrice(item.priceKobo)}</GText><GText>{item.description}</GText><GText tone="muted">Sold by {item.store} · {item.stock} in stock</GText><Pressable onPress={() => addToCart(item, qty)} style={[styles.details, { marginTop: 12, padding: 18, alignItems: 'center' }]}><GText tone="white" weight="bold">Add {qty} to cart</GText></Pressable></View></ScrollView></Modal>
  </Animated.View>;
}
const styles = StyleSheet.create({ card: { marginHorizontal: 12, marginVertical: 6, backgroundColor: '#FFF', borderRadius: 19, overflow: 'hidden', borderWidth: 1, borderColor: '#E3E7EF' }, seller: { height: 56, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 13, gap: 9 }, avatar: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#15213C', justifyContent: 'center', alignItems: 'center', borderWidth: 2, borderColor: '#F3B642' }, follow: { backgroundColor: '#090909', paddingHorizontal: 15, paddingVertical: 7, borderRadius: 20 }, hero: { flex: 1, backgroundColor: '#F3F4F6', justifyContent: 'center' }, arrow: { position: 'absolute', top: '46%', backgroundColor: '#FFF', width: 32, height: 32, borderRadius: 20, alignItems: 'center', justifyContent: 'center' }, status: { position: 'absolute', bottom: 10, left: 12, backgroundColor: '#FFF', paddingHorizontal: 9, paddingVertical: 5, borderRadius: 20 }, dots: { position: 'absolute', bottom: 12, alignSelf: 'center', flexDirection: 'row', gap: 4, padding: 5, backgroundColor: '#FFF', borderRadius: 12 }, dot: { width: 5, height: 5, borderRadius: 3, backgroundColor: '#BBD0F0' }, dotActive: { width: 15, backgroundColor: '#111626' }, views: { position: 'absolute', bottom: 11, right: 9, paddingHorizontal: 9, paddingVertical: 4, borderRadius: 20, flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(0,0,0,.45)' }, body: { paddingHorizontal: 13, paddingTop: 11, paddingBottom: 12 }, actions: { flexDirection: 'row', alignItems: 'center', gap: 13, height: 30, marginBottom: 9 }, action: { flexDirection: 'row', alignItems: 'center', gap: 4 }, pill: { alignSelf: 'flex-start', borderWidth: 1, borderColor: '#FFDACD', borderRadius: 20, paddingHorizontal: 6, paddingVertical: 3 }, priceRow: { marginTop: 13, marginBottom: 11, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, stepper: { paddingHorizontal: 10, height: 31, flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: '#DFE4EB', borderRadius: 20 }, bottom: { flexDirection: 'row', gap: 8, height: 39 }, cart: { width: 42, backgroundColor: '#F13D32', borderRadius: 11, alignItems: 'center', justifyContent: 'center' }, details: { flex: 1, borderRadius: 11, backgroundColor: '#0C1020', alignItems: 'center', justifyContent: 'center' }, modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 20 } });
