import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { useRouter } from 'expo-router';
import { useAuth } from '@/hooks/use-auth';
import type { FeedItem } from './data';

type Entry = { item: FeedItem; quantity: number };
type State = {
  liked: string[]; saved: string[]; followed: string[]; cart: Entry[];
  requireAccount: (action: () => void) => void;
  toggleLike: (id: string) => void; toggleSave: (id: string) => void;
  toggleFollow: (store: string) => void; addToCart: (item: FeedItem, quantity?: number) => void;
  removeFromCart: (id: string) => void;
};
const Context = createContext<State | null>(null);
export function FeedProvider({ children }: { children: ReactNode }) {
  const router = useRouter();
  const { user } = useAuth();
  const [liked, setLiked] = useState<string[]>([]);
  const [saved, setSaved] = useState<string[]>([]);
  const [followed, setFollowed] = useState<string[]>([]);
  const [cart, setCart] = useState<Entry[]>([]);
  useEffect(() => { setLiked([]); setSaved([]); setFollowed([]); setCart([]); }, [user?.id]);
  const requireAccount = (action: () => void) => {
    if (!user) { router.push('/login'); return; }
    action();
  };
  const toggle = (ids: string[], id: string) => ids.includes(id) ? ids.filter(x => x !== id) : [...ids, id];
  const toggleLike = (id: string) => requireAccount(() => setLiked(prev => toggle(prev, id)));
  const toggleSave = (id: string) => requireAccount(() => setSaved(prev => toggle(prev, id)));
  const toggleFollow = (store: string) => requireAccount(() => setFollowed(prev => toggle(prev, store)));
  const addToCart = (item: FeedItem, quantity = 1) => requireAccount(() => setCart(prev => {
    const match = prev.find(x => x.item.id === item.id);
    if (!match) return [...prev, { item, quantity: Math.min(quantity, item.stock) }];
    return prev.map(x => x.item.id === item.id ? { ...x, quantity: Math.min(item.stock, x.quantity + quantity) } : x);
  }));
  const removeFromCart = (id: string) => setCart(prev => prev.filter(x => x.item.id !== id));
  return <Context.Provider value={{ liked, saved, followed, cart, requireAccount, toggleLike, toggleSave, toggleFollow, addToCart, removeFromCart }}>{children}</Context.Provider>;
}
export function useFeedState() { const state = useContext(Context); if (!state) throw new Error('FeedProvider is missing'); return state; }
