import { useState } from 'react';
import { KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { GText } from '@/components/gleenc/text';
import { Colors } from '@/constants/theme';
import { useFeedState } from './feed-state';

export function Comments({ open, close, title }: { open: boolean; close: () => void; title: string }) {
  const [message, setMessage] = useState('');
  const [notes, setNotes] = useState<string[]>([]);
  const { requireAccount } = useFeedState();
  function submit() {
    const value = message.trim();
    if (!value) return;
    requireAccount(() => { setNotes(previous => [value, ...previous]); setMessage(''); });
  }
  return <Modal visible={open} animationType="slide" presentationStyle="pageSheet" onRequestClose={close}>
    <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={styles.header}><GText weight="bold" style={styles.title}>Comments · {title}</GText><Pressable onPress={close} accessibilityLabel="Close comments"><Ionicons name="close" size={26} color={Colors.light.text} /></Pressable></View>
      <ScrollView style={styles.list} keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 20 }}>
        {notes.length ? notes.map((value, index) => <View key={`${index}-${value}`} style={styles.note}><GText weight="bold">You</GText><GText style={{ marginTop: 5 }}>{value}</GText></View>) : <GText tone="muted" style={{ textAlign: 'center', marginTop: 50 }}>Be the first to leave a comment.</GText>}
      </ScrollView>
      <View style={styles.inputRow}><TextInput value={message} onChangeText={setMessage} placeholder="Add a comment..." placeholderTextColor={Colors.light.textMuted} style={styles.input} /><Pressable onPress={submit} accessibilityLabel="Post comment"><Ionicons name="send" size={23} color={Colors.light.red} /></Pressable></View>
    </KeyboardAvoidingView>
  </Modal>;
}
const styles = StyleSheet.create({ root: { flex: 1, backgroundColor: '#FFF' }, header: { padding: 20, borderBottomWidth: 1, borderColor: Colors.light.border, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, title: { fontSize: 17, flex: 1 }, list: { flex: 1 }, note: { backgroundColor: '#F7F8FA', padding: 14, borderRadius: 14, marginBottom: 9 }, inputRow: { flexDirection: 'row', padding: 14, alignItems: 'center', gap: 12, borderTopWidth: 1, borderColor: Colors.light.border }, input: { flex: 1, backgroundColor: '#F5F7FA', color: Colors.light.text, borderRadius: 18, padding: 12, fontFamily: 'ReoSans-Medium' } });
