// Visual fixtures. Replace with normalized GET /feed results when API integration begins.
export type FeedItem = {
  id: string; kind: 'video' | 'product'; name: string; priceKobo: number;
  image: string; images?: string[]; videoUrl?: string;
  store: string; handle: string; category: string; description: string;
  likes: number; comments: number; views: number; stock: number; createdAt: number;
};
export const FEED: FeedItem[] = [
  { id: 'rice-video', kind: 'video', name: 'Jollof Rice Combo', priceKobo: 250000, store: 'Tasty Bowl',
    handle: '@tasty-bowl', category: 'Food', description: 'Fresh campus meals available today. Fast pickup and delivery.',
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=1000',
    videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4',
    likes: 3800, comments: 420, views: 12000, stock: 8, createdAt: 1789880000 },
  { id: 'chicken-pie', kind: 'product', name: 'Grilled Chicken Pie', priceKobo: 315000, store: 'Movers',
    handle: '@movers', category: 'Food', description: 'Freshly prepared chicken pie with swift delivery.',
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=1000',
    images: [ 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=1000', 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=1000' ],
    likes: 3, comments: 3, views: 9, stock: 2, createdAt: 1789870000 },
  { id: 'noodles', kind: 'product', name: 'Belleful noodles', priceKobo: 525000, store: 'Movers',
    handle: '@movers', category: 'Food', description: 'Prepared to order for lunch.',
    image: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=1000',
    likes: 5, comments: 1, views: 4, stock: 6, createdAt: 1789860000 },
];
export const PROFILE_PRODUCTS: FeedItem[] = [
  { id: 'store-noodles', kind: 'product', name: 'Belleful noodles', priceKobo: 525000, store: 'Movers', handle: '@movers', category: 'Food', description: 'Made fresh each day.', image: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=800', likes: 7, comments: 0, views: 4, stock: 6, createdAt: 1789870000 },
  { id: 'store-cake', kind: 'product', name: 'Cake', priceKobo: 525000, store: 'Movers', handle: '@movers', category: 'Food', description: 'Celebration cakes.', image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800', likes: 2, comments: 0, views: 4, stock: 6, createdAt: 1789860000 },
  { id: 'store-rice', kind: 'product', name: 'Fried Rice', priceKobo: 525000, store: 'Movers', handle: '@movers', category: 'Food', description: 'Hot and ready.', image: 'https://images.unsplash.com/photo-1512058564366-18510be2db19?w=800', likes: 4, comments: 0, views: 4, stock: 5, createdAt: 1789850000 },
  FEED[1],
];
export const formatPrice = (value: number) => `₦${(value / 100).toLocaleString('en-NG', { maximumFractionDigits: 0 })}`;
export const shortCount = (value: number) => value >= 1000 ? `${(value / 1000).toFixed(value >= 10000 ? 0 : 1)}k` : String(value);
