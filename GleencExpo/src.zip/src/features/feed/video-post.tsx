import { useEffect, useState } from 'react';
import { Image, Pressable, Share, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useVideoPlayer, VideoView } from 'expo-video';
import { useRouter } from 'expo-router';
import { GText } from '@/components/gleenc/text';
import { Colors } from '@/constants/theme';
import { formatPrice, shortCount, type FeedItem } from './data';
import { Comments } from './comments';
import { useFeedState } from './feed-state';

export function VideoPost({ item, height, active }: { item: FeedItem; height: number; active: boolean }) {
  const router = useRouter();
  const { liked, saved, followed, toggleLike, toggleSave, toggleFollow, addToCart } = useFeedState();
  const [muted, setMuted] = useState(true);
  const [paused, setPaused] = useState(false);
  const [commentsOpen, setCommentsOpen] = useState(false);
  const player = useVideoPlayer(item.videoUrl ?? null, p => { p.loop = true; p.muted = true; });
  useEffect(() => { if (active && !paused && item.videoUrl) player.play(); else player.pause(); }, [active, paused, item.videoUrl, player]);
  useEffect(() => { player.muted = muted; }, [muted, player]);
  return <View style={[styles.root, { height }]}>
    {item.videoUrl ? <VideoView style={StyleSheet.absoluteFillObject} player={player} nativeControls={false} contentFit="cover" surfaceType="textureView" /> : <Image source={{ uri: item.image }} style={StyleSheet.absoluteFillObject} resizeMode="cover" />}
    <View pointerEvents="none" style={styles.dim} />
    <Pressable onPress={() => setPaused(p => !p)} style={StyleSheet.absoluteFillObject} accessibilityLabel={paused ? 'Play video' : 'Pause video'} />
    {paused && <Ionicons name="play-circle" size={66} color="rgba(255,255,255,0.8)" style={styles.centerPlay} />}
    <Pressable onPress={() => setMuted(m => !m)} accessibilityLabel={muted ? 'Unmute video' : 'Mute video'} style={styles.mute}><Ionicons name={muted ? 'volume-mute' : 'volume-high'} size={20} color="#FFF" /></Pressable>
    <View style={styles.rail}>
      <Pressable style={styles.railButton} onPress={() => toggleLike(item.id)} accessibilityLabel="Like video"><Ionicons name={liked.includes(item.id) ? 'heart' : 'heart-outline'} color={liked.includes(item.id) ? Colors.light.red : '#FFF'} size={29} /><GText tone="white" weight="bold" style={styles.railLabel}>{shortCount(item.likes + (liked.includes(item.id) ? 1 : 0))}</GText></Pressable>
      <Pressable style={styles.railButton} onPress={() => setCommentsOpen(true)} accessibilityLabel="Video comments"><Ionicons name="chatbubble-outline" color="#FFF" size={27} /><GText tone="white" weight="bold" style={styles.railLabel}>{shortCount(item.comments)}</GText></Pressable>
      <Pressable style={styles.railButton} onPress={() => toggleSave(item.id)} accessibilityLabel="Save video"><Ionicons name={saved.includes(item.id) ? 'bookmark' : 'bookmark-outline'} color={saved.includes(item.id) ? Colors.light.yellow : '#FFF'} size={28} /><GText tone="white" style={styles.railLabel}>Save</GText></Pressable>
      <Pressable style={styles.railButton} onPress={() => Share.share({ message: `${item.name} · ${formatPrice(item.priceKobo)} on Gleenc` })} accessibilityLabel="Share video"><Ionicons name="paper-plane-outline" color="#FFF" size={29} /><GText tone="white" style={styles.railLabel}>Share</GText></Pressable>
      <Pressable style={styles.add} onPress={() => addToCart(item)} accessibilityLabel="Add to cart"><Ionicons name="cart-outline" color="#FFF" size={27} /></Pressable>
    </View>
    <View style={styles.caption}>
      <View style={styles.seller}><View style={styles.avatar}><GText tone="white" weight="bold">{item.store[0]}</GText></View><Pressable onPress={() => router.push('/store')}><GText tone="white" weight="bold" style={{ fontSize: 16 }}>{item.store}</GText><GText tone="white" style={{ fontSize: 12 }}>{item.handle}</GText></Pressable><Pressable style={styles.follow} onPress={() => toggleFollow(item.store)}><GText weight="bold" style={{ fontSize: 12 }}>{followed.includes(item.store) ? 'Following' : 'Follow'}</GText></Pressable></View>
      <GText tone="white" weight="bold" style={{ fontSize: 20, marginTop: 15 }}>{item.name}</GText>
      <GText tone="white" style={{ fontSize: 19 }}>{formatPrice(item.priceKobo)}</GText>
      <GText tone="white" style={{ fontSize: 13, marginTop: 12, lineHeight: 20 }} numberOfLines={2}>{item.description}</GText>
    </View>
    <Comments open={commentsOpen} close={() => setCommentsOpen(false)} title={item.name} />
  </View>;
}
const styles = StyleSheet.create({ root: { backgroundColor: '#111', overflow: 'hidden' }, dim: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.10)' }, mute: { position: 'absolute', right: 20, top: 15, width: 40, height: 40, borderRadius: 22, backgroundColor: 'rgba(0,0,0,.4)', alignItems: 'center', justifyContent: 'center' }, centerPlay: { position: 'absolute', alignSelf: 'center', top: '42%' }, rail: { position: 'absolute', right: 12, bottom: 24, gap: 18, alignItems: 'center' }, railButton: { alignItems: 'center', minWidth: 46 }, railLabel: { fontSize: 11, marginTop: 4 }, add: { width: 51, height: 51, borderRadius: 26, backgroundColor: '#F23F37', alignItems: 'center', justifyContent: 'center', marginTop: 2 }, caption: { position: 'absolute', left: 20, right: 77, bottom: 24 }, seller: { flexDirection: 'row', gap: 9, alignItems: 'center' }, avatar: { backgroundColor: '#F24036', height: 39, width: 39, borderRadius: 20, alignItems: 'center', justifyContent: 'center' }, follow: { backgroundColor: '#FFF', paddingHorizontal: 15, paddingVertical: 8, borderRadius: 20, marginLeft: 3 } });
