function normalizeUrl(url: string) {
  return url.trim().replace(/\/+$/, '');
}

const configuredApiUrl =
  process.env.EXPO_PUBLIC_API_URL?.trim();

export const AppConfig = {
  name: 'Gleenc',

  apiBaseUrl: normalizeUrl(
    configuredApiUrl ||
      'https://gleank.onrender.com/api',
  ),

  apiTimeoutMs: 45_000,

  supportEmail: 'support@gleenc.com',

  currency: 'NGN',

  locale: 'en-NG',

  platformFeePercent: 5,

  pagination: {
    defaultPageSize: 20,
    maximumPageSize: 100,
  },
} as const;