import { Platform } from 'react-native';

const brand = {
  red: '#FF3C00',
  redDark: '#DE370C',
  yellow: '#FBE703',
  ink: '#111626',
  muted: '#738096',
  line: '#E7EBF2',
  white: '#FFFFFF',
};

export const Colors = {
  light: {
    primary: brand.red, primaryDark: brand.redDark, primaryLight: '#FFF0EA',
    background: brand.white, surface: brand.white, surfaceSecondary: '#F6F8FB',
    text: brand.ink, textSecondary: '#48546A', textMuted: brand.muted,
    textInverse: brand.white, border: brand.line, divider: brand.line,
    success: '#238C52', successLight: '#E8F8EF', warning: '#CA8705',
    warningLight: '#FFF5D9', error: '#D92D20', errorLight: '#FFF0EE',
    info: '#2876C7', infoLight: '#EAF4FF', icon: brand.ink,
    tabIconDefault: '#8B95A6', tabIconSelected: brand.ink, tint: brand.red,
    link: brand.red, overlay: 'rgba(9,13,24,0.52)', disabled: '#B9C0CB',
    placeholder: '#98A3B5', yellow: brand.yellow, red: brand.red,
  },
  dark: {
    primary: brand.red, primaryDark: brand.redDark, primaryLight: '#482115',
    background: '#0E111A', surface: '#171C28', surfaceSecondary: '#242B39',
    text: '#FFFFFF', textSecondary: '#CDD3DD', textMuted: '#9BA6B7',
    textInverse: '#FFFFFF', border: '#303747', divider: '#303747',
    success: '#4CC781', successLight: '#153A28', warning: '#F9C64F',
    warningLight: '#483819', error: '#FF7168', errorLight: '#4B201E',
    info: '#75B7FF', infoLight: '#1B3550', icon: '#FFFFFF',
    tabIconDefault: '#A1AABA', tabIconSelected: '#FFFFFF', tint: brand.red,
    link: '#FF7550', overlay: 'rgba(0,0,0,0.68)', disabled: '#566070',
    placeholder: '#808A9A', yellow: brand.yellow, red: brand.red,
  },
};
export type ThemeMode = keyof typeof Colors;
export type AppColors = (typeof Colors)[ThemeMode];
export const Spacing = {
  none: 0, xs: 4, sm: 8, md: 12, lg: 16, xl: 20,
  xxl: 24, xxxl: 32, section: 40, screenHorizontal: 20,
  one: 4, two: 8, three: 12, four: 16, five: 20,
  six: 24, eight: 32, ten: 40,
};
export const BorderRadius = {
  none: 0, xs: 4, sm: 8, md: 12, lg: 16, xl: 20, xxl: 24, full: 999,
};
export const FontSize = {
  xs: 11, sm: 13, base: 15, md: 16, lg: 18, xl: 20,
  xxl: 24, title: 28, display: 34,
};
export const FontWeight = {
  regular: '400', medium: '500', semibold: '600', bold: '700', extrabold: '800',
} as const;
export const Layout = {
  screenMaxWidth: 600, buttonHeight: 52, inputHeight: 52,
  headerHeight: 60, bottomTabHeight: 68, productCardWidth: 170,
};
export const Shadows = {
  small: Platform.select({ ios: { shadowColor: '#111626', shadowOpacity: 0.08, shadowRadius: 6, shadowOffset: { width: 0, height: 2 } }, android: { elevation: 2 }, default: {} }),
  medium: Platform.select({ ios: { shadowColor: '#111626', shadowOpacity: 0.12, shadowRadius: 12, shadowOffset: { width: 0, height: 5 } }, android: { elevation: 5 }, default: {} }),
  large: Platform.select({ ios: { shadowColor: '#111626', shadowOpacity: 0.16, shadowRadius: 20, shadowOffset: { width: 0, height: 9 } }, android: { elevation: 9 }, default: {} }),
};
export const Fonts = { sans: 'ReoSans-Medium', serif: 'ReoSans-Medium', rounded: 'ReoSans-Medium', mono: Platform.OS === 'ios' ? 'Menlo' : 'monospace' };
export const MaxContentWidth = 720;
export const BottomTabInset = 96;
