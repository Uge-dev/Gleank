import { useColorScheme } from './use-color-scheme';

import {
    BorderRadius,
    Colors,
    FontSize,
    FontWeight,
    Layout,
    Shadows,
    Spacing,
    type ThemeMode,
} from '@/constants/theme';

export function useAppTheme() {
  const systemColorScheme = useColorScheme();

  const mode: ThemeMode =
    systemColorScheme === 'dark' ? 'dark' : 'light';

  return {
    mode,
    isDark: mode === 'dark',
    colors: Colors[mode],
    spacing: Spacing,
    borderRadius: BorderRadius,
    fontSize: FontSize,
    fontWeight: FontWeight,
    layout: Layout,
    shadows: Shadows,
  };
}

export type AppTheme = ReturnType<typeof useAppTheme>;