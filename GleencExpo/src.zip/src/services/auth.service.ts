import {
    ApiError,
    apiRequest,
} from '@/services/api-client';
import type {
    ApiMessageResponse,
    AuthApiResponse,
    AuthPayload,
    LoginInput,
    RegisterInput,
} from '@/types';

function extractAuthPayload(
  response: AuthApiResponse,
): AuthPayload {
  const user = response.data?.user ?? response.user;
  const store =
    response.data?.store ?? response.store ?? null;

  if (!user) {
    throw new ApiError(
      500,
      'The server returned an invalid account response.',
    );
  }

  return {
    user,
    store,
    emailVerificationRequired:
      response.data?.emailVerificationRequired ??
      response.emailVerificationRequired,
  };
}

export async function getCurrentSession() {
  const response =
    await apiRequest<AuthApiResponse>('/auth/me');

  return extractAuthPayload(response);
}

export async function login(input: LoginInput) {
  const response =
    await apiRequest<AuthApiResponse>(
      '/auth/login',
      {
        method: 'POST',
        body: JSON.stringify({
          email: input.email.trim().toLowerCase(),
          password: input.password,
        }),
      },
    );

  return extractAuthPayload(response);
}

export async function register(
  input: RegisterInput,
) {
  const response =
    await apiRequest<AuthApiResponse>(
      '/auth/register',
      {
        method: 'POST',
        body: JSON.stringify({
          name: input.name.trim(),
          email: input.email.trim().toLowerCase(),
          password: input.password,
          role: 'buyer',
          campus: '',
        }),
      },
    );

  return extractAuthPayload(response);
}

export function logout() {
  return apiRequest<void>('/auth/logout', {
    method: 'POST',
  });
}

export function resendEmailVerification() {
  return apiRequest<ApiMessageResponse>(
    '/auth/resend-verification',
    {
      method: 'POST',
    },
  );
}

export function verifyEmail(token: string) {
  return apiRequest<ApiMessageResponse>(
    '/auth/verify-email',
    {
      method: 'POST',
      body: JSON.stringify({
        token: token.trim(),
      }),
    },
  );
}

export function requestPasswordReset(
  email: string,
) {
  return apiRequest<ApiMessageResponse>(
    '/auth/forgot-password',
    {
      method: 'POST',
      body: JSON.stringify({
        email: email.trim().toLowerCase(),
      }),
    },
  );
}

export function resetPassword(
  token: string,
  password: string,
) {
  return apiRequest<ApiMessageResponse>(
    '/auth/reset-password',
    {
      method: 'POST',
      body: JSON.stringify({
        token: token.trim(),
        password,
      }),
    },
  );
}