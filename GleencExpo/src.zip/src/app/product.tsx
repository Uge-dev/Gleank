import { Image, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GText } from '@/components/gleenc/text';
import { Colors } from '@/constants/theme';
import { FEED, PROFILE_PRODUCTS, formatPrice } from '@/features/feed/data';
import { useFeedState } from '@/features/feed/feed-state';
export default function ProductDetails() {
  const { id } = useLocalSearchParams<{ id: string }>(); const router = useRouter();
  const item = [...FEED, ...PROFILE_PRODUCTS].find(p => p.id === id);
  const { saved, toggleSave, addToCart } = useFeedState();
  if (!item) return <SafeAreaView style={styles.root}><GText style={{ padding: 20 }}>Product unavailable.</GText></SafeAreaView>;
  return <SafeAreaView edges={['top', 'bottom']} style={styles.root}><View style={styles.bar}><Pressable onPress={() => router.back()} accessibilityLabel="Back"><Ionicons name="arrow-back" size={25} color={Colors.light.text} /></Pressable><GText weight="bold" style={{ fontSize: 18 }}>Product details</GText><Pressable onPress={() => toggleSave(item.id)} accessibilityLabel="Save product"><Ionicons name={saved.includes(item.id) ? 'bookmark' : 'bookmark-outline'} size={24} color={Colors.light.red} /></Pressable></View><ScrollView><Image source={{ uri: item.image }} style={styles.image} /><View style={styles.body}><GText tone="red" weight="bold" style={{ fontSize: 22 }}>{formatPrice(item.priceKobo)}</GText><GText weight="bold" style={{ fontSize: 23 }}>{item.name}</GText><GText tone="muted">{item.category} · {item.stock} in stock</GText><GText style={{ marginTop: 18, lineHeight: 22 }}>{item.description}</GText><Pressable onPress={() => router.push('/store')} style={styles.seller}><Ionicons name="storefront-outline" size={21} color={Colors.light.red} /><GText>{item.store}</GText><Ionicons name="chevron-forward" size={20} color={Colors.light.textMuted} /></Pressable></View></ScrollView><Pressable onPress={() => addToCart(item)} style={styles.cart}><Ionicons name="cart-outline" size={22} color="#FFF" /><GText tone="white" weight="bold">Add to cart</GText></Pressable></SafeAreaView>;
}
const styles = StyleSheet.create({ root: { flex: 1, backgroundColor: '#FFF' }, bar: { height: 55, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 18 }, image: { width: '100%', height: 375 }, body: { padding: 20, gap: 8 }, seller: { marginTop: 22, paddingVertical: 18, flexDirection: 'row', alignItems: 'center', gap: 10, borderTopWidth: 1, borderColor: Colors.light.border }, cart: { margin: 18, padding: 16, backgroundColor: Colors.light.red, borderRadius: 14, justifyContent: 'center', alignItems: 'center', flexDirection: 'row', gap: 10 } });
