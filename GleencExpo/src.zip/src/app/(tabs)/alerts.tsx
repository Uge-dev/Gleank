import { Pressable, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GText } from '@/components/gleenc/text';
import { Colors } from '@/constants/theme';
import { useAuth } from '@/hooks/use-auth';
export default function Alerts() {
  const { user } = useAuth(); const router = useRouter();
  return <SafeAreaView edges={['top']} style={styles.root}><GText weight="bold" style={styles.title}>Alerts</GText><View style={styles.center}><Ionicons name="notifications-outline" size={54} color={Colors.light.red} /><GText weight="bold" style={{ fontSize: 17 }}>{user ? 'No alerts yet' : 'Get updates when you sign in'}</GText><GText tone="muted" style={{ textAlign: 'center' }}>Your order and seller updates will appear here.</GText>{!user && <Pressable onPress={() => router.push('/login')} style={styles.button}><GText tone="white" weight="bold">Sign in</GText></Pressable>}</View></SafeAreaView>;
}
const styles = StyleSheet.create({ root: { flex: 1, backgroundColor: '#FFF' }, title: { fontSize: 25, padding: 20 }, center: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 35, gap: 12 }, button: { backgroundColor: Colors.light.red, borderRadius: 13, paddingHorizontal: 20, paddingVertical: 12, marginTop: 10 } });
