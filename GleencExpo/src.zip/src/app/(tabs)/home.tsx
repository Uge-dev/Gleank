import { useRef, useState } from 'react';
import { useRouter } from 'expo-router';
import { useAuth } from '@/hooks/use-auth';
import { useFeedState } from '@/features/feed/feed-state';
import { FlatList, Pressable, StyleSheet, View, type ViewToken } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GText } from '@/components/gleenc/text';
import { Colors } from '@/constants/theme';
import { FEED } from '@/features/feed/data';
import { VideoPost } from '@/features/feed/video-post';
import { ProductPost } from '@/features/feed/product-post';

const labels = ['Hot Product', 'New Vendors', 'Following'] as const;
export default function Home() {
  const router = useRouter(); const { user } = useAuth(); const { followed } = useFeedState();
  const [tab, setTab] = useState<(typeof labels)[number]>('Hot Product');
  const [height, setHeight] = useState(620);
  const [activeId, setActiveId] = useState(FEED[0].id);
  const onViewable = useRef(({ viewableItems }: { viewableItems: ViewToken[] }) => {
    if (viewableItems[0]?.item?.id) setActiveId(viewableItems[0].item.id);
  }).current;
  const items = [...FEED].filter(item => tab !== 'Following' || (user && followed.includes(item.store))).sort((a, b) => b.createdAt - a.createdAt);
  return <SafeAreaView edges={['top']} style={styles.safe}>
    <View style={styles.header}><View style={{ flex: 1 }} />
      {labels.map(label => <Pressable key={label} style={[styles.link, tab === label && styles.selected]} onPress={() => { setTab(label); setActiveId(FEED[0].id); }}><GText tone={tab === label ? 'red' : 'ink'} style={{ fontSize: 12 }}>{label}</GText></Pressable>)}
      <View style={styles.icons}><Pressable onPress={() => router.push('/alerts')} accessibilityLabel="Alerts"><Ionicons name="notifications-outline" size={23} color={Colors.light.text} /></Pressable><Pressable onPress={() => router.push('/market')} accessibilityLabel="Search market"><Ionicons name="search-outline" size={23} color={Colors.light.text} /></Pressable></View>
    </View>
    <View style={{ flex: 1 }} onLayout={event => setHeight(event.nativeEvent.layout.height)}>
      {tab === 'Following' && !user ? <View style={styles.empty}><GText weight="bold" style={{ fontSize: 18 }}>See the sellers you follow</GText><GText tone="muted">Sign in to follow stores and creators.</GText><Pressable onPress={() => router.push('/login')} style={styles.signin}><GText tone="white" weight="bold">Sign in</GText></Pressable></View> : <FlatList key={tab} data={items} keyExtractor={item => item.id} pagingEnabled showsVerticalScrollIndicator={false}
        viewabilityConfig={{ itemVisiblePercentThreshold: 70 }} onViewableItemsChanged={onViewable}
        getItemLayout={(_, index) => ({ length: height, offset: height * index, index })}
        ListEmptyComponent={<View style={styles.empty}><GText tone="muted">Follow a seller to see posts here.</GText></View>}
        renderItem={({ item }) => item.kind === 'video' ? <VideoPost item={item} active={activeId === item.id} height={height} /> : <ProductPost item={item} height={height} />} />}
    </View>
  </SafeAreaView>;
}
const styles = StyleSheet.create({ safe: { flex: 1, backgroundColor: '#FFF' }, header: { height: 52, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', borderBottomWidth: 1, borderColor: '#EDF0F5', paddingHorizontal: 9 }, link: { height: 52, justifyContent: 'center', paddingHorizontal: 9 }, selected: { borderBottomWidth: 2, borderColor: Colors.light.red }, icons: { flex: 1, flexDirection: 'row', justifyContent: 'flex-end', gap: 10 }, empty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, padding: 30 }, signin: { backgroundColor: Colors.light.red, borderRadius: 14, paddingVertical: 11, paddingHorizontal: 22 } });
