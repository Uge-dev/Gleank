import Ionicons from '@expo/vector-icons/Ionicons';
import { useMemo, useState } from 'react';
import {
    FlatList,
    ScrollView,
    StyleSheet,
    View,
} from 'react-native';

import { ProductFeedCard } from '@/components/products/product-feed-card';
import { AnimatedPressable } from '@/components/ui/animated-pressable';
import { AppInput } from '@/components/ui/app-input';
import { AppText } from '@/components/ui/app-text';
import { Screen } from '@/components/ui/screen';
import {
    DEMO_CATEGORIES,
    DEMO_PRODUCTS,
} from '@/data/demo-products';
import { useAppTheme } from '@/hooks/use-app-theme';

export default function DiscoverScreen() {
  const { colors } = useAppTheme();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All');

  const products = useMemo(() => {
    const search = query.trim().toLowerCase();

    return DEMO_PRODUCTS.filter((product) => {
      const matchesCategory =
        category === 'All' || product.category === category;

      const matchesSearch =
        `${product.name} ${product.seller} ${product.category}`
          .toLowerCase()
          .includes(search);

      return matchesCategory && matchesSearch;
    });
  }, [category, query]);

  return (
    <Screen keyboardAvoiding={false}>
      <View style={styles.heading}>
        <AppText variant="heading1">Explore</AppText>
        <AppText tone="secondary">
          A little discovery goes a long way.
        </AppText>

        <AppInput
          placeholder="Search products or stores"
          accessibilityLabel="Search products or stores"
          value={query}
          onChangeText={setQuery}
          autoCorrect={false}
          returnKeyType="search"
          leftIcon={
            <Ionicons
              name="search-outline"
              size={20}
              color={colors.textSecondary}
            />
          }
        />
      </View>

      <View>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categories}
        >
          {DEMO_CATEGORIES.map((item) => {
            const selected = item === category;

            return (
              <AnimatedPressable
                key={item}
                onPress={() => setCategory(item)}
                accessibilityRole="button"
                accessibilityState={{ selected }}
                style={[
                  styles.chip,
                  {
                    backgroundColor: selected
                      ? colors.primary
                      : colors.surfaceSecondary,
                  },
                ]}
              >
                <AppText
                  variant="label"
                  tone={selected ? 'inverse' : 'primary'}
                >
                  {item}
                </AppText>
              </AnimatedPressable>
            );
          })}
        </ScrollView>
      </View>

      <FlatList
        data={products}
        keyExtractor={(item) => item.id}
        numColumns={2}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="on-drag"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.grid}
        columnWrapperStyle={styles.row}
        renderItem={({ item }) => (
          <View style={styles.cell}>
            <ProductFeedCard product={item} compact />
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons
              name="search-outline"
              size={40}
              color={colors.textSecondary}
            />
            <AppText variant="heading3">No matches yet</AppText>
            <AppText tone="secondary" align="center">
              Try another keyword or choose a different category.
            </AppText>
          </View>
        }
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  heading: { padding: 20, gap: 12 },
  categories: {
    paddingHorizontal: 20,
    paddingBottom: 16,
    gap: 8,
  },
  chip: {
    minHeight: 44,
    paddingHorizontal: 18,
    borderRadius: 24,
    justifyContent: 'center',
  },
  grid: { paddingHorizontal: 16, paddingBottom: 24 },
  row: { gap: 12, marginBottom: 12 },
  cell: { width: '48%' },
  empty: { padding: 30, alignItems: 'center', gap: 12 },
});