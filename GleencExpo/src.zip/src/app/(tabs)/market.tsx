import { useMemo, useState } from 'react';
import { FlatList, Image, Pressable, StyleSheet, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GText } from '@/components/gleenc/text';
import { Colors } from '@/constants/theme';
import { FEED, PROFILE_PRODUCTS, formatPrice } from '@/features/feed/data';

export default function Market() {
  const router = useRouter();
  const [query, setQuery] = useState('');
  const items = useMemo(() => [...FEED.filter(item => item.kind === 'product'), ...PROFILE_PRODUCTS].filter(item => `${item.name} ${item.store}`.toLowerCase().includes(query.toLowerCase())), [query]);
  return <SafeAreaView edges={['top']} style={styles.root}><View style={styles.header}><GText weight="bold" style={{ fontSize: 24 }}>Market</GText><GText tone="muted">Explore the latest products</GText></View><View style={styles.search}><Ionicons name="search-outline" size={20} color={Colors.light.textMuted} /><TextInput value={query} onChangeText={setQuery} placeholder="Search products or sellers" placeholderTextColor={Colors.light.textMuted} style={styles.input} /></View>
    <FlatList data={items} keyExtractor={item => item.id} numColumns={2} contentContainerStyle={{ padding: 9, paddingBottom: 30 }} columnWrapperStyle={{ gap: 10 }} renderItem={({ item }) => <Pressable style={styles.card} onPress={() => router.push({ pathname: '/product', params: { id: item.id } })}><Image source={{ uri: item.image }} style={styles.photo} /><View style={{ padding: 11 }}><GText weight="bold" numberOfLines={1}>{item.name}</GText><GText tone="muted" style={{ marginTop: 5, fontSize: 12 }}>{item.store}</GText><GText weight="bold" tone="red" style={{ marginTop: 6 }}>{formatPrice(item.priceKobo)}</GText></View></Pressable>} />
  </SafeAreaView>;
}
const styles = StyleSheet.create({ root: { flex: 1, backgroundColor: '#FFF' }, header: { padding: 20, gap: 5 }, search: { marginHorizontal: 15, marginBottom: 14, borderWidth: 1, borderColor: Colors.light.border, borderRadius: 20, paddingHorizontal: 15, flexDirection: 'row', alignItems: 'center', gap: 10 }, input: { height: 44, flex: 1, fontFamily: 'ReoSans-Medium', color: Colors.light.text }, card: { width: '48.7%', marginBottom: 12, borderWidth: 1, borderColor: Colors.light.border, borderRadius: 17, overflow: 'hidden' }, photo: { height: 180, width: '100%' } });
