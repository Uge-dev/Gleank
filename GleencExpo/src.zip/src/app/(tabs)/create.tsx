import Ionicons from '@expo/vector-icons/Ionicons';
import { useState } from 'react';
import { StyleSheet, View } from 'react-native';

import { AppButton } from '@/components/ui/app-button';
import { AppInput } from '@/components/ui/app-input';
import { AppText } from '@/components/ui/app-text';
import { Screen } from '@/components/ui/screen';
import { useAppTheme } from '@/hooks/use-app-theme';
import { formatKobo } from '@/utils/format-kobo';

type Draft = {
  name: string;
  description: string;
  priceKobo: number;
  stock: number;
};

export default function CreateScreen() {
  const { colors } = useAppTheme();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [stock, setStock] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [draft, setDraft] = useState<Draft | null>(null);

  function previewDraft() {
    const nextErrors: Record<string, string> = {};
    const amount = Number(price);
    const quantity = Number(stock);

    if (name.trim().length < 2) {
      nextErrors.name = 'Enter a product name with at least 2 characters.';
    }

    if (description.trim().length < 10) {
      nextErrors.description = 'Describe your product in at least 10 characters.';
    }

    if (
      !/^\d+(\.\d{1,2})?$/.test(price.trim()) ||
      !Number.isFinite(amount) ||
      amount <= 0 ||
      amount > 10000000
    ) {
      nextErrors.price = 'Enter a price between ₦0.01 and ₦10,000,000.';
    }

    if (
      !/^\d+$/.test(stock.trim()) ||
      !Number.isSafeInteger(quantity) ||
      quantity < 1 ||
      quantity > 100000
    ) {
      nextErrors.stock = 'Enter a whole quantity between 1 and 100,000.';
    }

    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) return;

    setDraft({
      name: name.trim(),
      description: description.trim(),
      priceKobo: Math.round(amount * 100),
      stock: quantity,
    });
  }

  return (
    <Screen scrollable contentContainerStyle={styles.content}>
      <AppText variant="heading1">Create something worth finding.</AppText>

      <AppText tone="secondary">
        Start with the details. Product photos and publishing come next.
      </AppText>

      <View
        style={[
          styles.notice,
          { backgroundColor: colors.primaryLight },
        ]}
      >
        <Ionicons
          name="sparkles-outline"
          size={24}
          color={colors.primary}
        />
        <AppText style={styles.flex}>
          Draft preview only. Nothing is published or saved permanently.
        </AppText>
      </View>

      <AppInput
        label="Product name"
        placeholder="What are you selling?"
        value={name}
        onChangeText={setName}
        maxLength={100}
        error={errors.name}
      />

      <AppInput
        label="Description"
        placeholder="Describe the condition, features and what is included."
        value={description}
        onChangeText={setDescription}
        maxLength={2000}
        multiline
        error={errors.description}
      />

      <AppInput
        label="Your price (₦)"
        placeholder="25000"
        value={price}
        onChangeText={setPrice}
        keyboardType="decimal-pad"
        error={errors.price}
      />

      <AppInput
        label="Available quantity"
        placeholder="10"
        value={stock}
        onChangeText={setStock}
        keyboardType="number-pad"
        error={errors.stock}
      />

      <AppButton title="Preview draft" onPress={previewDraft} />

      {draft && (
        <View
          style={[
            styles.preview,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
            },
          ]}
        >
          <AppText variant="label" tone="brand">
            DRAFT PREVIEW
          </AppText>
          <AppText variant="heading3">{draft.name}</AppText>
          <AppText variant="price">
            {formatKobo(draft.priceKobo)}
          </AppText>
          <AppText tone="secondary">{draft.description}</AppText>
          <AppText variant="caption">
            {draft.stock} available · Seller price before platform fees
          </AppText>
        </View>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  content: { padding: 20, gap: 20, paddingBottom: 36 },
  notice: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 16,
    borderRadius: 18,
  },
  preview: {
    padding: 20,
    borderRadius: 20,
    borderWidth: 1,
    gap: 10,
  },
});