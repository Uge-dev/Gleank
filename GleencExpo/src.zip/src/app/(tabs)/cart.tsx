import { FlatList, Image, Pressable, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GText } from '@/components/gleenc/text';
import { Colors } from '@/constants/theme';
import { useFeedState } from '@/features/feed/feed-state';
import { formatPrice } from '@/features/feed/data';
import { useAuth } from '@/hooks/use-auth';
export default function Cart() {
  const router = useRouter(); const { user } = useAuth(); const { cart, removeFromCart } = useFeedState();
  const total = cart.reduce((sum, row) => sum + row.item.priceKobo * row.quantity, 0);
  return <SafeAreaView edges={['top']} style={styles.root}><GText weight="bold" style={styles.title}>Your cart</GText>{!user ? <View style={styles.center}><Ionicons name="cart-outline" size={52} color={Colors.light.red} /><GText style={styles.message}>Sign in to add products to your cart.</GText><Pressable onPress={() => router.push('/login')} style={styles.cta}><GText tone="white" weight="bold">Sign in</GText></Pressable></View> : cart.length ? <><FlatList data={cart} keyExtractor={x => x.item.id} renderItem={({ item: row }) => <View style={styles.row}><Image source={{ uri: row.item.image }} style={styles.photo} /><View style={{ flex: 1, gap: 4 }}><GText weight="bold">{row.item.name}</GText><GText tone="muted">Qty {row.quantity}</GText><GText tone="red" weight="bold">{formatPrice(row.item.priceKobo * row.quantity)}</GText></View><Pressable onPress={() => removeFromCart(row.item.id)} accessibilityLabel="Remove from cart"><Ionicons name="trash-outline" color={Colors.light.red} size={22} /></Pressable></View>} /><View style={styles.footer}><GText weight="bold">Total: {formatPrice(total)}</GText><GText tone="muted" style={{ fontSize: 12, marginTop: 8 }}>Checkout will be connected during the commerce phase.</GText></View></> : <View style={styles.center}><Ionicons name="bag-handle-outline" size={52} color={Colors.light.red} /><GText style={styles.message}>Your cart is empty.</GText><Pressable onPress={() => router.push('/market')} style={styles.cta}><GText tone="white" weight="bold">Explore products</GText></Pressable></View>}</SafeAreaView>;
}
const styles = StyleSheet.create({ root: { flex: 1, backgroundColor: '#FFF' }, title: { fontSize: 25, padding: 20 }, center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 18, padding: 20 }, message: { textAlign: 'center', fontSize: 16 }, cta: { backgroundColor: Colors.light.red, paddingHorizontal: 25, paddingVertical: 14, borderRadius: 15 }, row: { flexDirection: 'row', alignItems: 'center', gap: 13, marginHorizontal: 18, paddingVertical: 12, borderBottomWidth: 1, borderColor: Colors.light.border }, photo: { width: 72, height: 72, borderRadius: 9 }, footer: { padding: 20, borderTopWidth: 1, borderColor: Colors.light.border } });
