import Ionicons from '@expo/vector-icons/Ionicons';
import { router } from 'expo-router';
import { useState } from 'react';
import { StyleSheet, View } from 'react-native';

import { AnimatedPressable } from '@/components/ui/animated-pressable';
import { AppButton } from '@/components/ui/app-button';
import { AppText } from '@/components/ui/app-text';
import { Screen } from '@/components/ui/screen';
import { useAppTheme } from '@/hooks/use-app-theme';

export default function OrdersScreen() {
  const { colors } = useAppTheme();
  const [section, setSection] = useState<'Purchases' | 'Sales'>(
    'Purchases',
  );

  return (
    <Screen>
      <View style={styles.heading}>
        <AppText variant="heading1">Your orders</AppText>
        <AppText tone="secondary">
          From checkout to confirmed delivery.
        </AppText>

        <View
          style={[
            styles.switcher,
            { backgroundColor: colors.surfaceSecondary },
          ]}
        >
          {(['Purchases', 'Sales'] as const).map((item) => (
            <AnimatedPressable
              key={item}
              onPress={() => setSection(item)}
              accessibilityRole="button"
              accessibilityState={{ selected: section === item }}
              style={[
                styles.option,
                {
                  backgroundColor:
                    section === item ? colors.background : 'transparent',
                },
              ]}
            >
              <AppText
                variant="label"
                tone={section === item ? 'brand' : 'secondary'}
              >
                {item}
              </AppText>
            </AnimatedPressable>
          ))}
        </View>
      </View>

      <View style={styles.empty}>
        <Ionicons
          name={section === 'Purchases' ? 'bag-handle-outline' : 'storefront-outline'}
          size={62}
          color={colors.primary}
        />

        <AppText variant="heading2" align="center">
          {section === 'Purchases'
            ? 'Your next find is waiting'
            : 'Your selling journey starts here'}
        </AppText>

        <AppText tone="secondary" align="center">
          This is the frontend preview. Live orders will appear after
          order integration.
        </AppText>

        <AppButton
          title={section === 'Purchases' ? 'Explore products' : 'Create a draft'}
          onPress={() =>
            router.navigate(section === 'Purchases' ? '/discover' : '/create')
          }
        />
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  heading: { padding: 20, gap: 12 },
  switcher: {
    flexDirection: 'row',
    borderRadius: 16,
    padding: 4,
    marginTop: 8,
  },
  option: {
    flex: 1,
    minHeight: 44,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  empty: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 28,
    gap: 20,
  },
});