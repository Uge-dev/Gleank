import { Ionicons } from '@expo/vector-icons';
import { Tabs } from 'expo-router';
import { StyleSheet } from 'react-native';
import { Colors } from '@/constants/theme';

export default function Layout() {
  return <Tabs screenOptions={{ headerShown: false, tabBarHideOnKeyboard: true,
    tabBarActiveTintColor: Colors.light.text, tabBarInactiveTintColor: '#8993A5',
    tabBarStyle: styles.tabs, tabBarLabelStyle: styles.label, tabBarItemStyle: { paddingTop: 4 } }}>
    <Tabs.Screen name="home" options={{ title: 'Home', tabBarIcon: ({ color, size, focused }) => <Ionicons name={focused ? 'home' : 'home-outline'} size={size} color={color} /> }} />
    <Tabs.Screen name="market" options={{ title: 'Market', tabBarIcon: ({ color, size, focused }) => <Ionicons name={focused ? 'bag-handle' : 'bag-handle-outline'} size={size} color={color} /> }} />
    <Tabs.Screen name="cart" options={{ title: 'Cart', tabBarIcon: ({ color, size, focused }) => <Ionicons name={focused ? 'cart' : 'cart-outline'} size={size} color={color} /> }} />
    <Tabs.Screen name="alerts" options={{ title: 'Alerts', tabBarIcon: ({ color, size, focused }) => <Ionicons name={focused ? 'notifications' : 'notifications-outline'} size={size} color={color} /> }} />
    <Tabs.Screen name="profile" options={{ title: 'Profile', tabBarIcon: ({ color, size, focused }) => <Ionicons name={focused ? 'person' : 'person-outline'} size={size} color={color} /> }} />
    <Tabs.Screen name="discover" options={{ href: null }} />
    <Tabs.Screen name="create" options={{ href: null }} />
    <Tabs.Screen name="orders" options={{ href: null }} />
  </Tabs>;
}
const styles = StyleSheet.create({ tabs: { height: 60, backgroundColor: '#FFF', borderTopWidth: 1, borderColor: '#E7EBF2' }, label: { fontFamily: 'ReoSans-Medium', fontSize: 10, marginBottom: 2 } });
