import '../global.css';
import { useEffect, useState } from 'react';
import { Stack } from 'expo-router';
import { useFonts } from 'expo-font';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider } from '@/context/auth-context';
import { FeedProvider } from '@/features/feed/feed-state';
import { BrandPreloader } from '@/components/gleenc/preloader';

export default function RootLayout() {
  const [readyFonts, fontError] = useFonts({
    'ReoSans-Light': require('../assets/fonts/ReoSans-Light.otf'),
    'ReoSans-Medium': require('../assets/fonts/ReoSans-Medium.otf'),
    'ReoSans-Bold': require('../assets/fonts/ReoSans-Bold.otf'),
  });
  const [waited, setWaited] = useState(false);
  useEffect(() => { const timer = setTimeout(() => setWaited(true), 1000); return () => clearTimeout(timer); }, []);
  return <SafeAreaProvider><AuthProvider><FeedProvider>
    {(!waited || (!readyFonts && !fontError)) ? <BrandPreloader /> : <Stack screenOptions={{ headerShown: false, animation: 'slide_from_right' }}>
      <Stack.Screen name="index" options={{ animation: 'fade' }} />
      <Stack.Screen name="(tabs)" options={{ animation: 'fade' }} />
      <Stack.Screen name="(auth)" options={{ animation: 'slide_from_right' }} />
      <Stack.Screen name="store" />
      <Stack.Screen name="product" />
      <Stack.Screen name="explore" />
    </Stack>}
  </FeedProvider></AuthProvider></SafeAreaProvider>;
}
