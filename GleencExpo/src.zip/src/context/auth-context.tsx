import {
    createContext,
    useCallback,
    useEffect,
    useMemo,
    useState,
    type ReactNode,
} from 'react';

import * as AuthService from '@/services/auth.service';
import type {
    AuthPayload,
    AuthUser,
    LoginInput,
    RegisterInput,
    SellerStore,
} from '@/types';

type AuthContextValue = {
  user: AuthUser | null;
  store: SellerStore | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  signIn: (input: LoginInput) => Promise<AuthPayload>;
  signUp: (input: RegisterInput) => Promise<AuthPayload>;
  signOut: () => Promise<void>;
  refreshSession: () => Promise<void>;
};

export const AuthContext =
  createContext<AuthContextValue | undefined>(
    undefined,
  );

type AuthProviderProps = {
  children: ReactNode;
};

export function AuthProvider({
  children,
}: AuthProviderProps) {
  const [user, setUser] =
    useState<AuthUser | null>(null);

  const [store, setStore] =
    useState<SellerStore | null>(null);

  const [isLoading, setIsLoading] =
    useState(true);

  const applySession = useCallback(
    (session: AuthPayload | null) => {
      setUser(session?.user ?? null);
      setStore(session?.store ?? null);
    },
    [],
  );

  const refreshSession = useCallback(
    async () => {
      try {
        const session =
          await AuthService.getCurrentSession();

        applySession(session);
      } catch {
        applySession(null);
      }
    },
    [applySession],
  );

  useEffect(() => {
    async function restoreSession() {
      setIsLoading(true);

      try {
        await refreshSession();
      } finally {
        setIsLoading(false);
      }
    }

    void restoreSession();
  }, [refreshSession]);

  const signIn = useCallback(
    async (input: LoginInput) => {
      const session =
        await AuthService.login(input);

      applySession(session);
      return session;
    },
    [applySession],
  );

  const signUp = useCallback(
    async (input: RegisterInput) => {
      const session =
        await AuthService.register(input);

      applySession(session);
      return session;
    },
    [applySession],
  );

  const signOut = useCallback(async () => {
    try {
      await AuthService.logout();
    } finally {
      applySession(null);
    }
  }, [applySession]);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      store,
      isLoading,
      isAuthenticated: Boolean(user),
      signIn,
      signUp,
      signOut,
      refreshSession,
    }),
    [
      isLoading,
      refreshSession,
      signIn,
      signOut,
      signUp,
      store,
      user,
    ],
  );

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}